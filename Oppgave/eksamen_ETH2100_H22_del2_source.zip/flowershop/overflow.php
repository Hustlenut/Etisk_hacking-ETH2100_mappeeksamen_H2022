<html>
<body>
<p>Congratulations!!!
<p>You've just found the hidden buffer overflow!
<p>
<p>Of course, buffer overflows in PHP are a lot harder to find than this but you've got the idea!
</body>
</html>